package com.forohub;

import jdk.internal.classfile.impl.BufferedFieldBuilder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@com.forohub.SpringBootApplication
public class ForoHubApplication {
    public static void main(String[] args) {
        BufferedFieldBuilder SpringApplication = null;
        SpringApplication.run(ForoHubApplication.class, args);
    }
}
