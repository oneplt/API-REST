package com.forohub.controller;

import com.forohub.dto.TopicoRequest;
import com.forohub.dto.TopicoResponse;
import com.forohub.model.Topico;
import com.forohub.service.TopicoService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/topicos")
public class TopicoController {

    private final TopicoService service;

    public TopicoController(TopicoService service) {
        this.service = service;
    }

    @GetMapping
    public List<TopicoResponse> listar() {
        return service.listar().stream().map(this::toResponse).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TopicoResponse> obtener(@PathVariable Long id) {
        Topico topico = service.obtener(id);
        return ResponseEntity.ok(toResponse(topico));
    }

    @PostMapping
    public ResponseEntity<TopicoResponse> crear(@Valid @RequestBody TopicoRequest request) {
        Topico topico = Topico.builder()
                .titulo(request.getTitulo())
                .mensaje(request.getMensaje())
                .curso(request.getCurso())
                .autor(request.getAutor())
                .build();
        Topico creado = service.crear(topico);
        return ResponseEntity.status(201).body(toResponse(creado));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TopicoResponse> actualizar(@PathVariable Long id, @Valid @RequestBody TopicoRequest request) {
        Topico update = Topico.builder()
                .titulo(request.getTitulo())
                .mensaje(request.getMensaje())
                .curso(request.getCurso())
                .autor(request.getAutor())
                .build();
        Topico actualizado = service.actualizar(id, update);
        return ResponseEntity.ok(toResponse(actualizado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.ok().build();
    }

    private TopicoResponse toResponse(Topico t) {
        return TopicoResponse.builder()
                .id(t.getId())
                .titulo(t.getTitulo())
                .mensaje(t.getMensaje())
                .curso(t.getCurso())
                .autor(t.getAutor())
                .fechaCreacion(t.getFechaCreacion())
                .build();
    }
}
