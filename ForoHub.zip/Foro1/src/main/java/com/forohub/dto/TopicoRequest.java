package com.forohub.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class TopicoRequest {
    @NotBlank
    private String titulo;

    @NotBlank
    private String mensaje;

    private String curso;

    private String autor;

    public long getTitulo() {
        return 0;
    }

    public Object getMensaje() {
        return null;
    }
}
