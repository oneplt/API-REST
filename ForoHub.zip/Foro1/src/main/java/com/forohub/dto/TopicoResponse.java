package com.forohub.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class TopicoResponse {
    private Long id;
    private String titulo;
    private String mensaje;
    private String curso;
    private String autor;
    private LocalDateTime fechaCreacion;
}
