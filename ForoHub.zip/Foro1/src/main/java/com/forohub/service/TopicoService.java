package com.forohub.service;

import com.forohub.exception.ResourceNotFoundException;
import com.forohub.model.Topico;
import com.forohub.repository.TopicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TopicoService {

    private final TopicoRepository repository;

    public TopicoService(TopicoRepository repository) {
        this.repository = repository;
    }

    public List<Topico> listar() {
        return repository.findAll();
    }

    public Topico obtener(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Tópico no encontrado con id: " + id));
    }

    public Topico crear(Topico topico) {
        return repository.save(topico);
    }

    public Topico actualizar(Long id, Topico topicoActualizado) {
        Topico topico = obtener(id);
        topico.setTitulo(topicoActualizado.getTitulo());
        topico.setMensaje(topicoActualizado.getMensaje());
        topico.setCurso(topicoActualizado.getCurso());
        topico.setAutor(topicoActualizado.getAutor());
        return repository.save(topico);
    }

    public void eliminar(Long id) {
        Topico t = obtener(id);
        repository.delete(t);
    }
}
